# SAS / SEMMA Quickstart

- Stages: **Sample → Explore → Modify → Model → Assess**.
- In SAS Enterprise Miner / Viya, build a process flow with nodes for each stage.
- Export the project diagram and assessment results into `semma_project/reports/`.
