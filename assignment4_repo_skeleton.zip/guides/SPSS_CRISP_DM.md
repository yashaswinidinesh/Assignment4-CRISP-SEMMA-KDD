# IBM SPSS Modeler — CRISP-DM Notes

- Use the built-in **CRISP-DM project tool** to annotate each phase and auto-generate reports.
- Capture screenshots of each phase (streams, nodes) for your repo and Medium article.
- Export the phase report and place it in `crisp_dm_project/reports/`.
